<?php
$error='';$done=false;
$requirements=['PHP 8.2 或以上'=>version_compare(PHP_VERSION,'8.2','>='),'PDO MySQL'=>extension_loaded('pdo_mysql'),'DOM'=>extension_loaded('dom'),'Fileinfo'=>extension_loaded('fileinfo'),'配置目录可写'=>is_writable(CMS_ROOT.'/storage')];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $lock=fopen(CMS_ROOT.'/storage/install.lock','c');
  try{
    verify_csrf();if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new RuntimeException('另一个安装正在进行，请稍后再试。');
    if(is_file(CMS_ROOT.'/storage/config.php'))throw new RuntimeException('安装已完成，请进入后台。');
    if(in_array(false,$requirements,true))throw new RuntimeException('运行环境尚未满足要求。');
    $c=['host'=>trim($_POST['host']??'localhost'),'port'=>(int)($_POST['port']??3306),'database'=>trim($_POST['database']??''),'username'=>trim($_POST['dbuser']??''),'password'=>$_POST['dbpassword']??''];
    if(!preg_match('/^[a-zA-Z0-9_.-]+$/',$c['host'])||!preg_match('/^[a-zA-Z0-9_-]+$/',$c['database'])||$c['port']<1||$c['port']>65535)throw new RuntimeException('数据库地址、名称或端口格式不正确。');
    $email=trim($_POST['email']??'');$password=$_POST['password']??'';
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<12||strlen($password)>72||$password!==($_POST['confirm']??''))throw new RuntimeException('请填写有效邮箱和 12–72 字节的密码，并确认两次输入一致。');
    try{$db=connect_db($c);}catch(Throwable $e){throw new RuntimeException('数据库连接失败，请核对主机面板中的数据库地址、名称、用户名和密码。');}
    if($db->query("SHOW TABLES LIKE 'cms_%'")->fetch())throw new RuntimeException('数据库中已存在 CMS 数据表。为防止覆盖，请选择一个新的空数据库。');
    $schema=file_get_contents(CMS_ROOT.'/app/schema.sql');
    foreach(explode(';',$schema) as $sql)if(trim($sql))$db->exec($sql);
    $db->beginTransaction();
    query('INSERT INTO cms_users(email,password,role) VALUES(?,?,?)',[$email,password_hash($password,PASSWORD_DEFAULT),'admin']);
    put_settings('site',['title'=>trim($_POST['title']??'我的网站'),'tagline'=>'','indexable'=>false]);
    $db->commit();
    $serialized='<?php return '.var_export($c,true).';';
    $tmp=CMS_ROOT.'/storage/config.tmp.php';
    if(file_put_contents($tmp,$serialized,LOCK_EX)===false||!rename($tmp,CMS_ROOT.'/storage/config.php'))throw new RuntimeException('无法保存配置。请检查 storage 目录权限，保留数据库并联系维护人员。');
    @chmod(CMS_ROOT.'/storage/config.php',0600);
    session_regenerate_id(true);$_SESSION=[];$done=true;
  }catch(Throwable $e){$error=$e instanceof PDOException?'数据库初始化失败，请确认账号具有建表权限。若已创建部分 CMS 表，请换一个空数据库重试。':$e->getMessage();}
  finally{if($lock){flock($lock,LOCK_UN);fclose($lock);}}
}
ob_start();
?><main class="setup"><h1>安装你的 CMS</h1><?php if($done): ?><p>安装成功。管理员账户已创建，安装入口已锁定。</p><a class="button" href="?admin=1">登录后台</a><?php else: ?>
<p>填写主机数据库信息并创建首个管理员，无需运行命令。</p><ul><?php foreach($requirements as $label=>$ok): ?><li><?= $ok?'✓':'✗' ?> <?= h($label) ?></li><?php endforeach ?></ul>
<?php if($error): ?><p class="error"><?= h($error) ?></p><?php endif ?>
<form method="post"><?= csrf_field() ?><h2>数据库连接</h2>
<?php foreach(['host'=>['数据库地址','localhost'],'port'=>['数据库端口','3306'],'database'=>['数据库名称',''],'dbuser'=>['数据库用户名',''],'dbpassword'=>['数据库密码','']] as $key=>$spec): ?><label><?= h($spec[0]) ?><input required name="<?= $key ?>" type="<?= $key==='dbpassword'?'password':'text' ?>" value="<?= $key==='dbpassword'?'':h($_POST[$key]??$spec[1]) ?>"></label><?php endforeach ?>
<h2>网站及管理员</h2><label>站点标题<input required name="title" value="<?= h($_POST['title']??'我的网站') ?>"></label><label>管理员邮箱<input required type="email" name="email" value="<?= h($_POST['email']??'') ?>"></label><label>管理员密码（至少 12 字节）<input required type="password" name="password" minlength="12" autocomplete="new-password"></label><label>确认密码<input required type="password" name="confirm" autocomplete="new-password"></label><button <?= in_array(false,$requirements,true)?'disabled':'' ?>>安装并创建管理员</button></form><?php endif ?></main><?php layout('安装 CMS',ob_get_clean(),false);
