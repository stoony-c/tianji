<?php
declare(strict_types=1);
ini_set('display_errors', '0');
session_name('mycms_session');
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off','path'=>'/']);
session_start();
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: SAMEORIGIN');
function h(mixed $v): string {return htmlspecialchars((string)($v??''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');}
function csrf(): string {return $_SESSION['csrf'] ??= bin2hex(random_bytes(32));}
function csrf_field(): string {return '<input type="hidden" name="csrf" value="'.csrf().'">';}
function verify_csrf(): void {if(!hash_equals(csrf(), (string)($_POST['csrf']??''))) throw new RuntimeException('页面已过期，请刷新后再试。');}
function redirect(string $url): never {header('Location: '.$url);exit;}
function connect_db(array $c): PDO {
    $pdo=new PDO('mysql:host='.$c['host'].';port='.$c['port'].';dbname='.$c['database'].';charset=utf8mb4',$c['username'],$c['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_EMULATE_PREPARES=>false]);
    return $pdo;
}
function query(string $sql,array $args=[]): PDOStatement {global $db;$s=$db->prepare($sql);$s->execute($args);return $s;}
function records(string $kind,bool $public=false): array {
    return query('SELECT * FROM cms_records WHERE kind=?'.($public?' AND published=1':'').' ORDER BY id DESC',[$kind])->fetchAll(PDO::FETCH_ASSOC);
}
function record(int $id): ?array {$r=query('SELECT * FROM cms_records WHERE id=?',[$id])->fetch(PDO::FETCH_ASSOC);return $r?:null;}
function data(?array $r): array {return $r ? (json_decode($r['data'],true)?:[]) : [];}
function settings(string $key): array {$r=query('SELECT value FROM cms_settings WHERE name=?',[$key])->fetchColumn();return $r?(json_decode($r,true)?:[]):[];}
function put_settings(string $key,array $value): void {query('INSERT INTO cms_settings(name,value) VALUES(?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',[$key,json_encode($value,JSON_UNESCAPED_UNICODE)]);}
function user(): ?array {if(empty($_SESSION['uid']))return null;$u=query('SELECT id,email,role FROM cms_users WHERE id=?',[$_SESSION['uid']])->fetch(PDO::FETCH_ASSOC);return $u?:null;}
function can_edit(string $kind): bool {$u=user();return $u && ($u['role']==='admin'||($u['role']==='editor'&&in_array($kind,['products','news','categories','pages','media','seo'],true)));}
function safe_url(string $url): string {return preg_match('~^(https?://|mailto:|tel:|\./|/(?!/)|\?(?!/)|#)~i',$url)&&!preg_match('/[\x00-\x20\\\\]/',$url)?$url:'';}
function clean_html(string $html): string {
    if(trim($html)==='')return '';
    $dom=new DOMDocument();libxml_use_internal_errors(true);
    $dom->loadHTML('<?xml encoding="UTF-8"><div>'.$html.'</div>',LIBXML_HTML_NOIMPLIED|LIBXML_HTML_NODEFDTD|LIBXML_NONET);
    $allowed=explode(' ','div span section article header footer nav main aside h1 h2 h3 h4 h5 h6 p br hr a img picture source video audio ul ol li strong b em i u blockquote pre code table thead tbody tr th td figure figcaption details summary');
    foreach(iterator_to_array($dom->getElementsByTagName('*')) as $node){
        if(!in_array(strtolower($node->tagName),$allowed,true)){$node->parentNode?->removeChild($node);continue;}
        foreach(iterator_to_array($node->attributes) as $attr){
            $name=strtolower($attr->name);$value=trim($attr->value);
            if(str_starts_with($name,'on')||!in_array($name,['class','id','title','alt','href','src','width','height','controls','poster','target','rel','colspan','rowspan','loading','aria-label'],true)|| (in_array($name,['href','src','poster'],true)&&!safe_url($value)))$node->removeAttribute($attr->name);
        }
        if($node->tagName==='a')$node->setAttribute('rel','noopener noreferrer');
    }
    libxml_clear_errors();$result='';foreach($dom->documentElement?->childNodes??[] as $child)$result.=$dom->saveHTML($child);return $result;
}
function css(string $text): string {return str_ireplace(['</style','<script'],['',''],$text);}
function media_url(mixed $id): string {if(!$id)return ''; $r=record((int)$id);return $r&&$r['kind']==='media'?'?media='.rawurlencode($r['slug']):'';}
function page_url(array $r): string {
    $d=data($r);if($r['kind']==='pages'){return match($d['pageType']??'custom'){'home'=>'./','products'=>'?view=products','news'=>'?view=news',default=>'?page='.rawurlencode($r['slug'])};}
    return '?'.($r['kind']==='products'?'product':($r['kind']==='categories'?'category':'news')).'='.rawurlencode($r['slug']);
}
function layout(string $title,string $body,bool $admin=true): void {
    $brand=$admin?(trim((string)(settings('system')['name']??''))?:'天机1.0'):'';$updateNotice='';
    if($admin&&(user()['role']??'')==='admin')try{
        require_once CMS_ROOT.'/app/updater.php';$update=tj_check();
        if(empty($update['error'])&&!empty($update['raw']))$updateNotice='<div class="tj-update-notice"><a href="?admin=1&amp;section=updates">发现新版本 '.h($update['latest']).'，查看更新</a></div>';
    }catch(Throwable $e){error_log('Update check: '.$e->getMessage());}
    echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.h($title).'</title><link rel="stylesheet" href="assets/admin.css"></head><body>'.($admin?'<header><strong>'.h($brand).'</strong><a href="./" target="_blank">查看网站</a></header>':'').$updateNotice.$body.'<footer class="cms-copyright'.($admin?' cms-copyright--admin':'').'">sToony版权所有</footer></body></html>';
}
