(()=>{
const field=document.getElementById('menu-json'),box=document.getElementById('menu-editor'),pages=JSON.parse(document.getElementById('page-options').textContent);let nodes=JSON.parse(field.value||'[]'),drag=-1;
const sync=()=>field.value=JSON.stringify(nodes);
function subtreeEnd(i){let j=i+1;while(j<nodes.length&&nodes[j].depth>nodes[i].depth)j++;return j;}
function draw(){box.replaceChildren();nodes.forEach((node,i)=>{
const row=document.createElement('div');row.className='menu-row';row.style.marginLeft=node.depth*28+'px';row.draggable=true;
row.addEventListener('dragstart',e=>{drag=i;e.dataTransfer.setData('text/plain',String(i));});row.addEventListener('dragover',e=>e.preventDefault());
row.addEventListener('drop',e=>{e.preventDefault();if(drag<0||drag===i)return;const end=subtreeEnd(drag);if(i>=drag&&i<end)return;const depth=nodes[i].depth,delta=depth-nodes[drag].depth;if(nodes.slice(drag,end).some(n=>n.depth+delta>2))return;let target=i;const block=nodes.splice(drag,end-drag);if(drag<i)target-=block.length;block.forEach(n=>n.depth+=delta);nodes.splice(target,0,...block);drag=-1;draw();});
const handle=document.createElement('span');handle.textContent='☰ ';row.append(handle);
const label=document.createElement('input');label.placeholder='菜单文字';label.value=node.label;label.oninput=()=>{node.label=label.value;sync();};row.append(label);
const select=document.createElement('select');const custom=document.createElement('option');custom.value='0';custom.textContent='自定义链接';select.append(custom);pages.forEach(p=>{const o=document.createElement('option');o.value=p.id;o.textContent=p.title;select.append(o);});select.value=String(node.page||0);select.onchange=()=>{node.page=Number(select.value);sync();};row.append(select);
const url=document.createElement('input');url.placeholder='链接地址，例如 ?view=news';url.value=node.url||'';url.oninput=()=>{node.url=url.value;sync();};row.append(url);
const btn=(text,fn)=>{const b=document.createElement('button');b.type='button';b.className='secondary';b.textContent=text;b.onclick=fn;row.append(b);};
btn('左移',()=>{if(node.depth===0)return;const end=subtreeEnd(i);for(let j=i;j<end;j++)nodes[j].depth--;draw();});
btn('右移',()=>{if(i===0||node.depth>=2||node.depth>nodes[i-1].depth)return;const end=subtreeEnd(i);if(nodes.slice(i,end).some(n=>n.depth>=2))return;for(let j=i;j<end;j++)nodes[j].depth++;draw();});
btn('删除',()=>{if(confirm('删除此项及其子菜单？')){nodes.splice(i,subtreeEnd(i)-i);draw();}});box.append(row);
});sync();}
document.getElementById('menu-add').onclick=()=>{nodes.push({label:'新菜单',depth:0,page:0,url:'./'});draw();};draw();
})();
