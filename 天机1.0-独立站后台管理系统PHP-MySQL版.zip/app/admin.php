<?php
header('Cache-Control: no-store');header('X-Robots-Tag: noindex, nofollow');
require CMS_ROOT.'/app/fields.php';
$error='';$notice='';$u=user();
if(!$u){
 if($_SERVER['REQUEST_METHOD']==='POST')try{
   verify_csrf();$email=strtolower(trim($_POST['email']??''));$key=hash('sha256',($_SERVER['REMOTE_ADDR']??'').':'.$email);
   $attempt=query('SELECT * FROM cms_login_attempts WHERE key_hash=?',[$key])->fetch(PDO::FETCH_ASSOC);
   if($attempt&&$attempt['expires']>time()&&$attempt['attempts']>=8)throw new RuntimeException('尝试次数较多，请 15 分钟后重试。');
   $account=query('SELECT * FROM cms_users WHERE email=?',[$email])->fetch(PDO::FETCH_ASSOC);
   if(!$account||!password_verify($_POST['password']??'',$account['password'])){
     query('INSERT INTO cms_login_attempts(key_hash,attempts,expires) VALUES(?,1,?) ON DUPLICATE KEY UPDATE attempts=IF(expires<?,1,attempts+1),expires=VALUES(expires)',[$key,time()+900,time()]);
     throw new RuntimeException('邮箱或密码不正确。');
   }
   query('DELETE FROM cms_login_attempts WHERE key_hash=?',[$key]);session_regenerate_id(true);$_SESSION['uid']=$account['id'];$_SESSION['csrf']=bin2hex(random_bytes(32));redirect('?admin=1');
 }catch(Throwable $e){$error=$e->getMessage();}
 layout('登录后台','<main class="setup"><h1>登录后台</h1>'.($error?'<p class="error">'.h($error).'</p>':'').'<form method="post">'.csrf_field().'<label>电子邮件<input type="email" name="email" required autocomplete="username"></label><label>密码<input type="password" name="password" required autocomplete="current-password"></label><button>登录</button></form></main>',false);return;
}
$kind=(string)($_GET['section']??'products');if(!isset($sections[$kind]))$kind='products';
if($kind==='updates'){require CMS_ROOT.'/app/updates.php';return;}
$globals=in_array($kind,['site','navigation','footer','system'],true);$id=(int)($_GET['id']??0);
$current=$id?record($id):null;if($current&&$current['kind']!==$kind){http_response_code(404);exit('记录不存在');}
if($_SERVER['REQUEST_METHOD']==='POST')try{
 verify_csrf();$action=$_POST['action']??'save';
 if($action==='logout'){$_SESSION=[];session_destroy();redirect('?admin=1');}
 if(!can_edit($kind))throw new RuntimeException('当前账号没有修改权限。');
 if($kind==='users'){
   $uid=(int)($_POST['uid']??0);$email=strtolower(trim($_POST['email']??''));$role=$_POST['role']??'editor';$password=$_POST['password']??'';
   if(!in_array($role,['admin','editor','viewer'],true))throw new RuntimeException('角色不正确。');
   $db->beginTransaction();$admins=query("SELECT id FROM cms_users WHERE role='admin' FOR UPDATE")->fetchAll(PDO::FETCH_COLUMN);
   if($uid&&in_array($uid,array_map('intval',$admins),true)&&count($admins)===1&&($action==='delete'||$role!=='admin'))throw new RuntimeException('必须保留至少一个管理员。');
   if($action==='delete'){if($uid===$u['id'])throw new RuntimeException('不能删除当前登录账户。');query('DELETE FROM cms_users WHERE id=?',[$uid]);}
   else{
    if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('请输入有效邮箱。');
    if((!$uid||$password!=='')&&(strlen($password)<12||strlen($password)>72))throw new RuntimeException('密码长度应为 12–72 字节。');
    if($uid){query('UPDATE cms_users SET email=?,role=? WHERE id=?',[$email,$role,$uid]);if($password!=='')query('UPDATE cms_users SET password=? WHERE id=?',[password_hash($password,PASSWORD_DEFAULT),$uid]);}
    else query('INSERT INTO cms_users(email,password,role) VALUES(?,?,?)',[$email,password_hash($password,PASSWORD_DEFAULT),$role]);
   }$db->commit();$notice='用户设置已保存。';
 }elseif($kind==='seo'){
   $target=record((int)($_POST['target']??0));if(!$target||!in_array($target['kind'],['products','news','pages','categories'],true))throw new RuntimeException('页面不存在。');
   $d=data($target);$d['seo']=['keyword'=>trim($_POST['keyword']??''),'title'=>trim($_POST['seo_title']??''),'description'=>trim($_POST['description']??'')];
   query('UPDATE cms_records SET data=? WHERE id=?',[json_encode($d,JSON_UNESCAPED_UNICODE),$target['id']]);$notice='SEO 已保存。';
 }elseif($globals){
   $d=[];foreach($fields[$kind] as $k=>$spec)$d[$k]=$spec[1]==='checkbox'?!empty($_POST['fields'][$k]):($_POST['fields'][$k]??'');
   if(isset($d['html']))$d['html']=clean_html((string)$d['html']);put_settings($kind,$d);$notice='设置已保存。';
 }elseif($action==='delete'){
   if(!$current)throw new RuntimeException('记录不存在。');query('DELETE FROM cms_records WHERE id=?',[$id]);redirect('?admin=1&section='.urlencode($kind));
 }else{
   $title=trim($_POST['title']??'');$slug=trim($_POST['slug']??'');$published=isset($_POST['published'])?1:0;
   if(!$title||strlen($title)>570)throw new RuntimeException('请输入名称（最多 190 个字符）。');
   if(!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/',$slug))throw new RuntimeException('链接后缀只使用英文小写、数字和连字符。');
   $d=data($current);foreach($fields[$kind]??[] as $k=>$spec){$v=$_POST['fields'][$k]??'';$d[$k]=in_array($spec[1],['html'],true)?clean_html((string)$v):$v;}
   if($kind==='pages'&&($d['pageType']??'custom')!=='custom')foreach(records('pages') as $other)if((int)$other['id']!==$id&&(data($other)['pageType']??'')===$d['pageType'])throw new RuntimeException('此页面类型已绑定其他页面，请编辑已有页面。');
   if($kind==='menus'){
      $nodes=json_decode($_POST['menu_json']??'[]',true,32,JSON_THROW_ON_ERROR);if(!is_array($nodes)||count($nodes)>100)throw new RuntimeException('菜单最多 100 项。');$depth=0;$seen=[];
      foreach($nodes as &$node){$level=(int)($node['depth']??0);if($level<0||$level>2||$level>$depth+1||(!$seen&&$level!==0))throw new RuntimeException('菜单层级不正确。');$depth=$level;$seen[]=1;$node=['label'=>trim((string)($node['label']??'')),'depth'=>$level,'page'=>(int)($node['page']??0),'url'=>safe_url((string)($node['url']??''))];if(!$node['label'])throw new RuntimeException('菜单文字不能为空。');}unset($node);$d['nodes']=$nodes;
   }
   if($kind==='media'&&!empty($_FILES['file']['name'])){
      $f=$_FILES['file'];if($f['error']!==UPLOAD_ERR_OK||$f['size']>50*1024*1024)throw new RuntimeException('上传失败，文件最多 50MB，且不能超过主机限制。');
      $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);$types=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif','video/mp4'=>'mp4','video/webm'=>'webm','audio/mpeg'=>'mp3','application/pdf'=>'pdf'];
      if(!isset($types[$mime]))throw new RuntimeException('支持 JPG、PNG、WebP、GIF、MP4、WebM、MP3 和 PDF。');
      $dir=CMS_ROOT.'/storage/uploads';if(!is_dir($dir))mkdir($dir,0700,true);$name=bin2hex(random_bytes(20)).'.'.$types[$mime];if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$name))throw new RuntimeException('文件保存失败。');$d['file']=$name;$d['mime']=$mime;$published=1;
   }
   if($kind==='media'&&empty($d['file']))throw new RuntimeException('请选择一个文件。');
   $args=[$title,$slug,$published,json_encode($d,JSON_UNESCAPED_UNICODE)];
   if($id)query('UPDATE cms_records SET title=?,slug=?,published=?,data=? WHERE id=?',[...$args,$id]);
   else {query('INSERT INTO cms_records(title,slug,published,data,kind) VALUES(?,?,?,?,?)',[...$args,$kind]);$id=(int)$db->lastInsertId();}
   redirect('?admin=1&section='.urlencode($kind).'&id='.$id.'&saved=1');
 }
}catch(Throwable $e){if($db->inTransaction())$db->rollBack();$error=$e instanceof PDOException?'保存失败：链接后缀或邮箱可能已被使用，请检查后重试。':$e->getMessage();}
ob_start();?><aside><?php foreach($sections as $key=>$label): ?><a class="<?= $kind===$key?'active':'' ?>" href="?admin=1&amp;section=<?= h($key) ?>"><?= h($label) ?></a><?php endforeach ?><small><?= h($u['email']) ?></small><form method="post"><?= csrf_field() ?><button class="secondary" name="action" value="logout">退出登录</button></form></aside><main class="workspace"><h1><?= h($sections[$kind]) ?></h1>
<?php if($error): ?><p class="error"><?= h($error) ?></p><?php endif ?><?php if($notice||isset($_GET['saved'])): ?><p class="success"><?= h($notice?:'保存成功。') ?></p><?php endif ?>
<?php if($kind==='users'): ?>
<?php if($u['role']!=='admin'): ?><p>仅管理员可以管理用户。</p><?php else: ?>
<?php foreach([...query('SELECT id,email,role FROM cms_users ORDER BY id')->fetchAll(PDO::FETCH_ASSOC),['id'=>0,'email'=>'','role'=>'editor']] as $account): ?><form class="card" method="post"><?= csrf_field() ?><input type="hidden" name="uid" value="<?= $account['id'] ?>"><h2><?= $account['id']?'编辑用户':'新增用户' ?></h2><label>邮箱<input type="email" name="email" required value="<?= h($account['email']) ?>"></label><label>密码（已有用户留空则不修改）<input type="password" name="password" autocomplete="new-password"></label><label>角色<select name="role"><?php foreach(['admin'=>'管理员','editor'=>'编辑','viewer'=>'只读'] as $v=>$label): ?><option value="<?= $v ?>" <?= $account['role']===$v?'selected':'' ?>><?= $label ?></option><?php endforeach ?></select></label><button>保存</button><?php if($account['id']): ?><button name="action" value="delete" onclick="return confirm('确定删除这个用户？')">删除</button><?php endif ?></form><?php endforeach ?><?php endif ?>
<?php elseif($kind==='seo'): ?>
<?php foreach(['pages','products','news','categories'] as $type):foreach(records($type) as $r):$seo=data($r)['seo']??[]; ?><form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="target" value="<?= $r['id'] ?>"><h2><?= h($sections[$type].' · '.$r['title']) ?></h2><small><?= h(page_url($r)) ?></small><label>Focus Keyword<input name="keyword" value="<?= h($seo['keyword']??'') ?>"></label><label>Title<input name="seo_title" value="<?= h($seo['title']??'') ?>"></label><label>Description<textarea name="description"><?= h($seo['description']??'') ?></textarea></label><?php if(can_edit('seo')): ?><button>保存 SEO</button><?php endif ?></form><?php endforeach;endforeach ?>
<?php elseif($globals): ?><form method="post" class="card"><?= csrf_field() ?><?php foreach($fields[$kind] as $key=>$spec)echo field_input($key,$spec,settings($kind)); ?><?php if(can_edit($kind)): ?><button>保存设置</button><?php endif ?></form>
<?php elseif($id||isset($_GET['new'])):$values=data($current); ?>
<div class="actions"><a href="?admin=1&amp;section=<?= h($kind) ?>">返回列表</a><?php if($current): ?><a target="_blank" href="?preview=<?= $id ?>">预览已保存内容</a><?php endif ?></div>
<form method="post" enctype="multipart/form-data" class="card" id="editor"><?= csrf_field() ?><label>名称 / 标题<input name="title" required maxlength="190" value="<?= h($current['title']??'') ?>"></label><label>链接后缀<input name="slug" required pattern="[a-z0-9]+(-[a-z0-9]+)*" value="<?= h($current['slug']??'') ?>" placeholder="例如 company-news"></label><label><input type="checkbox" name="published" <?= ($current['published']??false)?'checked':'' ?>> 发布 / 启用（未勾选为草稿）</label>
<?php if($kind==='media'): ?><label>上传文件<input type="file" name="file" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,audio/mpeg,application/pdf"></label><?php if($current): ?><p>公开链接：<a href="<?= h(media_url($id)) ?>" target="_blank"><?= h(media_url($id)) ?></a> <button type="button" class="secondary" onclick="navigator.clipboard.writeText(new URL('<?= h(media_url($id)) ?>',location.href).href).then(()=>alert('链接已复制'))">复制完整链接</button></p><?php endif ?><?php endif ?>
<?php foreach($fields[$kind]??[] as $key=>$spec)echo field_input($key,$spec,$values); ?>
<?php if(str_ends_with($kind,'templates')): ?><label>从文件载入 HTML<input type="file" accept=".html,.htm" onchange="this.files[0]?.text().then(v=>document.querySelector('[name=&quot;fields[html]&quot;]').value=v)"></label><label>从文件载入 CSS<input type="file" accept=".css" onchange="this.files[0]?.text().then(v=>document.querySelector('[name=&quot;fields[css]&quot;]').value=v)"></label><p>变量：{{page.title}}、{{page.content}}、{{products.grid}}、{{products.count}}、{{news.grid}}、{{news.title}}、{{news.summary}}、{{news.image}}、{{news.content}}、{{product.name}}、{{product.content}}。</p><?php endif ?>
<?php if($kind==='menus'): ?><p>拖动行调整顺序，使用右移 / 左移设置二级、三级菜单。保存后生效。</p><div id="menu-editor"></div><button type="button" class="secondary" id="menu-add">添加菜单项</button><input type="hidden" id="menu-json" name="menu_json" value="<?= h(json_encode($values['nodes']??[],JSON_UNESCAPED_UNICODE)) ?>"><script type="application/json" id="page-options"><?= json_encode(array_map(fn($r)=>['id'=>$r['id'],'title'=>$r['title']],records('pages')),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?></script><script src="assets/menus.js"></script><?php endif ?>
<?php if(can_edit($kind)): ?><div class="actions"><button>保存</button><?php if($id): ?><button class="secondary" name="action" value="delete" onclick="return confirm('确定删除？')">删除</button><?php endif ?></div><?php endif ?></form>
<?php else: ?><?php if(can_edit($kind)): ?><p><a class="button" href="?admin=1&amp;section=<?= h($kind) ?>&amp;new=1">新增<?= h($sections[$kind]) ?></a></p><?php endif ?><table><thead><tr><th>名称</th><th>链接后缀</th><th>状态</th><th>更新时间</th></tr></thead><tbody><?php foreach(records($kind) as $r): ?><tr><td><a href="?admin=1&amp;section=<?= h($kind) ?>&amp;id=<?= $r['id'] ?>"><?= h($r['title']) ?></a></td><td><?= h($r['slug']) ?></td><td><?= $r['published']?'已启用':'草稿' ?></td><td><?= h($r['updated_at']) ?></td></tr><?php endforeach ?></tbody></table><?php endif ?></main><?php layout($sections[$kind],ob_get_clean());
