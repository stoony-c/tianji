<?php
declare(strict_types=1);
define('CMS_ROOT', __DIR__);
require CMS_ROOT . '/app/update-bootstrap.php';
require CMS_ROOT . '/app/core.php';
try {
    if (!is_file(CMS_ROOT . '/storage/config.php')) {
        require CMS_ROOT . '/app/install.php';
    } else {
        $config = require CMS_ROOT . '/storage/config.php';
        if (isset($_GET['install'])) { http_response_code(403); exit('系统已经安装，安装入口已关闭。'); }
        $db = connect_db($config);
        if (isset($_GET['admin']) || preg_match('~/admin/?$~', parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH))) require CMS_ROOT . '/app/admin.php';
        else require CMS_ROOT . '/app/frontend.php';
    }
} catch (Throwable $e) {
    error_log('CMS: '.$e->getMessage());
    http_response_code(500);
    echo '<p>系统暂时无法完成请求。请检查数据库连接或主机错误日志。</p>';
}
