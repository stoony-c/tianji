<?php
$sections=['products'=>'产品','news'=>'新闻','categories'=>'新闻分类','media'=>'媒体库','pages'=>'页面','product-templates'=>'产品详情模板','news-templates'=>'新闻详情模板','page-templates'=>'页面布局模板','menus'=>'导航菜单','footer-templates'=>'页脚模板','navigation'=>'顶部导航设置','footer'=>'页脚设置','seo'=>'SEO 管理','site'=>'站点设置','users'=>'用户'];
$sections['system']='系统设置';$sections['updates']='系统更新';
$fields=[
 'system'=>['name'=>['后台系统名称','text']],
 'products'=>['model'=>['产品型号','text'],'category'=>['产品分类','text'],'summary'=>['产品简介','textarea'],'cover'=>['主图','@media'],'content'=>['详细介绍 HTML','html'],'template'=>['详情模板','@product-templates']],
 'news'=>['category'=>['新闻分类','@categories'],'summary'=>['摘要','textarea'],'cover'=>['封面','@media'],'date'=>['发布日期','date'],'content'=>['正文 HTML','html'],'template'=>['新闻模板','@news-templates']],
 'categories'=>['description'=>['分类说明','textarea']],
 'pages'=>['pageType'=>['页面类型',['custom'=>'自定义页面','home'=>'主页','products'=>'产品总览','news'=>'新闻总览']],'content'=>['页面正文 HTML','html'],'template'=>['页面模板','@page-templates'],'html'=>['自定义 HTML','html'],'css'=>['自定义 CSS','css']],
 'product-templates'=>['html'=>['模板 HTML','html'],'css'=>['模板 CSS','css']],
 'news-templates'=>['html'=>['模板 HTML','html'],'css'=>['模板 CSS','css']],
 'page-templates'=>['html'=>['模板 HTML','html'],'css'=>['模板 CSS','css']],
 'footer-templates'=>['html'=>['模板 HTML','html'],'css'=>['模板 CSS','css']],
 'media'=>['alt'=>['图片替代文字','text']],
 'menus'=>[],
 'site'=>['title'=>['站点标题','text'],'tagline'=>['副标题','text'],'logo'=>['Logo','@media'],'indexable'=>['允许搜索引擎收录','checkbox']],
 'navigation'=>['menu'=>['选择顶部导航菜单','@menus']],
 'footer'=>['template'=>['选择页脚模板','@footer-templates'],'html'=>['自定义页脚 HTML','html'],'css'=>['自定义页脚 CSS','css'],'pages'=>['投放页面（留空表示全站）','@@pages']],
];
function field_input(string $key,array $spec,array $values): string {
 [$label,$type]=$spec;$value=$values[$key]??'';$out='<label>'.h($label);
 if(is_array($type)||str_starts_with($type,'@')){
   $multi=is_string($type)&&str_starts_with($type,'@@');
   $options=is_array($type)?$type:array_column(records(ltrim($type,'@')),'title','id');
   $out.='<select name="fields['.h($key).']'.($multi?'[]':'').'" '.($multi?'multiple size="5"':'').'><option value="">请选择</option>';
   foreach($options as $id=>$text){$selected=$multi?in_array((string)$id,array_map('strval',(array)$value),true):(string)$value===(string)$id;$out.='<option value="'.h($id).'" '.($selected?'selected':'').'>'.h($text).'</option>';}$out.='</select>';
 }elseif($type==='checkbox')$out.='<input type="checkbox" name="fields['.h($key).']" value="1" '.($value?'checked':'').'>';
 elseif(in_array($type,['textarea','html','css'],true))$out.='<textarea name="fields['.h($key).']" rows="'.($type==='textarea'?4:12).'">'.h($value).'</textarea>';
 else $out.='<input type="'.h($type).'" name="fields['.h($key).']" value="'.h($value).'">';
 return $out.'</label>';
}
