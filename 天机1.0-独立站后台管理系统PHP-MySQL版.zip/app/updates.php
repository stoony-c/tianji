<?php
if(($u['role']??'')!=='admin'){http_response_code(403);layout('系统更新','<main class="setup"><p>仅管理员可以更新系统。</p><a href="?admin=1">返回后台</a></main>',false);return;}
require_once CMS_ROOT.'/app/updater.php';$error='';
if($_SERVER['REQUEST_METHOD']==='POST')try{
 verify_csrf();$action=$_POST['action']??'';
 if($action==='logout'){$_SESSION=[];session_destroy();redirect('?admin=1');}
 if($action==='check')tj_check(true);
 elseif($action==='apply'){
   @set_time_limit(240);$info=tj_check(true);if($info['error']||empty($info['raw']))throw new RuntimeException($info['error']?:'当前没有可安装更新。');
   if(!hash_equals((string)($_POST['version']??''),(string)$info['latest']))throw new RuntimeException('发布版本已变化，请查看更新说明后重新确认。');
   $zip=tempnam(CMS_ROOT.'/storage','download-');try{file_put_contents($zip,tj_http($info['url'],32*1024*1024));tj_apply($info['raw'],$info['signature'],$zip);}finally{if(is_file($zip))unlink($zip);}
   redirect('?admin=1&section=updates&updated=1');
 }
}catch(Throwable $e){$error=$e->getMessage();}
$info=tj_check();$v=tj_version();$status=is_file(CMS_ROOT.'/storage/update-status.json')?json_decode(file_get_contents(CMS_ROOT.'/storage/update-status.json'),true):[];
ob_start();?><main class="setup"><a href="?admin=1">← 返回后台</a><h1>系统更新</h1><p>当前版本：<?= h($v['version']) ?></p><p>更新源：<a href="https://github.com/stoony-c/tianji/releases" target="_blank" rel="noopener">stoony-c/tianji 正式发布</a></p><p>后台每 6 小时检查一次。发现新版本后，由管理员确认安装。</p><?php if($error||$info['error']): ?><p class="error"><?= h($error?:$info['error']) ?></p><?php endif ?><?php if(!empty($status['message'])): ?><p class="success"><?= h($status['message']) ?></p><?php endif ?>
<form method="post"><?= csrf_field() ?><button name="action" value="check">检查更新</button></form>
<?php if(!$info['error']&&!empty($info['raw'])): ?><h2>可更新至 <?= h($info['latest']) ?></h2><p style="white-space:pre-wrap"><?= h($info['notes']??'') ?></p><p>更新前会备份将被替换的程序文件。数据库、上传文件和服务器配置会保留。本功能仅接受数据库结构版本相同的更新。</p><form method="post"><?= csrf_field() ?><input type="hidden" name="version" value="<?= h($info['latest']) ?>"><button name="action" value="apply" onclick="return confirm('确认安装此更新？更新期间网站请求可能需要短暂等待。')">立即更新</button></form><?php elseif(!$info['error']): ?><p>目前没有更高版本可安装。</p><?php endif ?><p><small>需要主机启用 cURL、OpenSSL、Zip 扩展，并允许程序目录写入。若升级中断，下一次请求会尝试从程序备份恢复。</small></p></main><?php layout('系统更新',ob_get_clean(),false);
