<?php
if(PHP_SAPI!=='cli'){http_response_code(403);exit;}
$root=dirname(__DIR__);$version=ltrim($argv[1]??'','v');$keyFile=$argv[2]??getenv('TIANJI_SIGNING_KEY_FILE');
if(!preg_match('/^\d+\.\d+\.\d+$/D',$version)||!is_file($keyFile))throw new RuntimeException('Usage: php tools/build-release.php v1.2.0 /path/to/private-key.pem');
define('CMS_ROOT',$root);
// Only load the allowlist functions; bootstrap is normally loaded by HTTP entrypoint.
$metadata=json_decode(file_get_contents($root.'/app/version.json'),true,16,JSON_THROW_ON_ERROR);
if($metadata['version']!==$version||$metadata['schema']!==1)throw new RuntimeException('版本标签必须与 app/version.json 一致，目前发布工具只支持 schema 1。');
$dist=$root.'/dist';if(!is_dir($dist))mkdir($dist,0700);
$zip=new ZipArchive();$zip->open($dist.'/tianji-update.zip',ZipArchive::CREATE|ZipArchive::OVERWRITE);$files=[];
foreach(['app','assets'] as $folder){foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/'.$folder,FilesystemIterator::SKIP_DOTS)) as $f){
 if(!$f->isFile()||$f->isLink())continue;$path=str_replace('\\','/',substr($f->getPathname(),strlen($root)+1));
 if(in_array($path,['app/update-bootstrap.php','app/update-public-key.pem'],true))continue;
 if(!preg_match('~^(app/[a-zA-Z0-9_-]+\.php|app/version\.json|assets/[a-zA-Z0-9_/-]+\.(css|js|png|jpg|webp|svg))$~D',$path))continue;
 $zip->addFile($f->getPathname(),$path);$files[$path]=hash_file('sha256',$f->getPathname());
}}$zip->close();ksort($files);
$raw=json_encode(['product'=>'tianji','version'=>$version,'schema'=>1,'sha256'=>hash_file('sha256',$dist.'/tianji-update.zip'),'files'=>$files],JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR);
$key=openssl_pkey_get_private(file_get_contents($keyFile));if(!$key||!openssl_sign($raw,$signature,$key,OPENSSL_ALGO_SHA256))throw new RuntimeException('签名失败。');
if(openssl_verify($raw,$signature,file_get_contents($root.'/app/update-public-key.pem'),OPENSSL_ALGO_SHA256)!==1)throw new RuntimeException('私钥与系统内置公钥不匹配。');
file_put_contents($dist.'/tianji-update.json',$raw);file_put_contents($dist.'/tianji-update.sig',base64_encode($signature));echo "Signed update package created for $version\n";
