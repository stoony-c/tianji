<?php
$site=settings('site');$preview=isset($_GET['preview']);
if($preview&&!user()){http_response_code(401);exit('请先登录后台再预览。');}
if($preview||empty($site['indexable']))header('X-Robots-Tag: noindex, nofollow');
if($preview)header('Cache-Control: no-store');
if(isset($_GET['media'])){
 $r=query("SELECT * FROM cms_records WHERE kind='media' AND slug=? AND published=1",[(string)$_GET['media']])->fetch(PDO::FETCH_ASSOC);$d=data($r?:null);$file=basename($d['file']??'');$path=CMS_ROOT.'/storage/uploads/'.$file;
 if(!$file||!is_file($path)){http_response_code(404);exit('文件不存在');}
 header('Content-Type: '.($d['mime']??'application/octet-stream'));header('Content-Length: '.filesize($path));header('Content-Disposition: inline; filename="'.$file.'"');header('Cache-Control: public, max-age=3600');readfile($path);return;
}
function cards(string $kind,?int $category=null): array {
 $items=array_values(array_filter(records($kind,true),fn($r)=>$category===null||(int)(data($r)['category']??0)===$category));$html='<div class="cms-grid">';
 foreach($items as $r){$d=data($r);$image=media_url($d['cover']??0);$html.='<article class="cms-card"><a href="'.h(page_url($r)).'">'.($image?'<img src="'.h($image).'" alt="'.h($r['title']).'">':'').'<h2>'.h($r['title']).'</h2></a><p>'.h($d['summary']??'').'</p></article>';}
 return [$html.'</div>',count($items)];
}
function render_template(string $html,array $vars): string {
 return clean_html(preg_replace_callback('/{{\s*([a-zA-Z0-9_.]+)\s*}}/',fn($m)=>$vars[$m[1]]??'', $html));
}
function active_template(mixed $id): array {$r=record((int)$id);return $r&&$r['published']?data($r):[];}
$r=null;$view=(string)($_GET['view']??'home');$category=null;$body='';$style='';$title=$site['title']??'我的网站';$seo=[];
if($preview){$r=record((int)$_GET['preview']);}
else{
 foreach(['page'=>'pages','product'=>'products','news'=>'news','category'=>'categories'] as $key=>$kind)if(isset($_GET[$key])){$r=query('SELECT * FROM cms_records WHERE kind=? AND slug=? AND published=1',[$kind,(string)$_GET[$key]])->fetch(PDO::FETCH_ASSOC)?:null;if(!$r){http_response_code(404);$body='<h1>页面不存在或尚未发布</h1>';}$view='detail';break;}
 if($view!=='detail')foreach(records('pages',true) as $candidate)if((data($candidate)['pageType']??'custom')===$view){$r=$candidate;break;}
}
if($r&&$r['kind']==='categories'){$category=(int)$r['id'];$view='news';$title=$r['title'];$seo=data($r)['seo']??[];}
[$productsGrid,$productsCount]=cards('products');[$newsGrid,$newsCount]=cards('news',$category);
$vars=['site.title'=>h($site['title']??'我的网站'),'site.tagline'=>h($site['tagline']??''),'products.grid'=>$productsGrid,'products.count'=>(string)$productsCount,'news.grid'=>$newsGrid,'news.count'=>(string)$newsCount];
if($r&&$r['kind']!=='categories'){
 $d=data($r);$title=$r['title'];$seo=$d['seo']??[];$content=clean_html($d['content']??'');$image=media_url($d['cover']??0);
 $prefix=$r['kind']==='products'?'product':($r['kind']==='news'?'news':'page');
 $values=['title'=>h($title),'name'=>h($title),'slug'=>h($r['slug']),'summary'=>h($d['summary']??''),'content'=>$content,'description'=>$content,'image'=>h($image),'model'=>h($d['model']??''),'publishedAt'=>h($d['date']??''),'category'=>h(record((int)($d['category']??0))['title']??($d['category']??''))];
 foreach($values as $key=>$value){$vars[$prefix.'.'.$key]=$value;$vars[$key]=$value;}
 $template=active_template($d['template']??0);
 if(str_ends_with($r['kind'],'templates')){$template=$d;$vars+=['page.title'=>'页面预览','page.content'=>'<p>这里显示页面正文。</p>','product.name'=>'产品预览','product.content'=>'<p>这里显示产品介绍。</p>','news.title'=>'新闻预览','news.content'=>'<p>这里显示新闻正文。</p>'];}
 $html=$template['html']??($d['html']??'');$style=$template['css']??($d['css']??'');
 if($html)$body=render_template($html,$vars);
 else{
   $body='<article><h1>'.h($title).'</h1>'.($image?'<img class="cover" src="'.h($image).'" alt="'.h($title).'">':'').'<p>'.h($d['summary']??'').'</p>'.$content.'</article>';
   if($r['kind']==='pages'&&($d['pageType']??'')==='products')$body.=$productsGrid;
   if($r['kind']==='pages'&&($d['pageType']??'')==='news')$body.=$newsGrid;
 }
}elseif(!$body){$body=match($view){'products'=>'<h1>产品中心</h1>'.$productsGrid,'news'=>'<h1>'.h($title===$site['title']?'新闻资讯':$title).'</h1>'.$newsGrid,default=>'<h1>'.h($site['title']??'我的网站').'</h1><p>'.h($site['tagline']??'欢迎访问。请在后台创建并发布主页。').'</p>'};}
$nav=settings('navigation');$menu=record((int)($nav['menu']??0));$links=[];
if($menu&&$menu['published']){
 $skip=null;foreach(data($menu)['nodes']??[] as $node){$depth=(int)$node['depth'];if($skip!==null&&$depth>$skip)continue;$skip=null;
   $target=!empty($node['page'])?record((int)$node['page']):null;
   if(!empty($node['page'])&&(!$target||!$target['published'])){$skip=$depth;continue;}
   $url=$target?page_url($target):safe_url($node['url']??'');if(!$url){$skip=$depth;continue;}$links[]=['depth'=>$depth,'url'=>$url,'label'=>$node['label']];
 }
}
$navHTML='<ul>'; $level=0;$first=true;foreach($links as $link){$depth=min($link['depth'],$level+($first?0:1));if(!$first){if($depth>$level)$navHTML.='<ul>';elseif($depth<$level)$navHTML.='</li>'.str_repeat('</ul></li>',$level-$depth);else $navHTML.='</li>';}$navHTML.='<li><a href="'.h($link['url']).'">'.h($link['label']).'</a>';$level=$depth;$first=false;}if(!$first)$navHTML.='</li>'.str_repeat('</ul></li>',$level);$navHTML.='</ul>';
$footer=settings('footer');$footerHTML='';$targets=array_filter((array)($footer['pages']??[]));
if(!$targets||($r&&$r['kind']==='pages'&&in_array((string)$r['id'],array_map('strval',$targets),true))){$ft=active_template($footer['template']??0);$footerHTML=render_template($ft['html']??($footer['html']??''),$vars);$style.="\n".($ft['css']??($footer['css']??''));}
$logo=media_url($site['logo']??0);
$seo['title']=trim((string)($seo['title']??''))?:$title;
?><!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= h($seo['title']??$title) ?></title><meta name="description" content="<?= h($seo['description']??'') ?>"><?php if(empty($site['indexable'])||$preview): ?><meta name="robots" content="noindex,nofollow"><?php endif ?><link rel="stylesheet" href="assets/site.css"><style><?= css($style) ?></style></head><body><header class="site-header"><a href="./"><?= $logo?'<img class="logo" src="'.h($logo).'" alt="'.h($site['title']??'').'">':h($site['title']??'我的网站') ?></a><nav><?= $navHTML ?></nav></header><?php if($preview): ?><p class="preview-note">预览模式：此内容不一定已对外发布。</p><?php endif ?><main class="site-main"><?= $body ?></main><footer><?= $footerHTML ?></footer></body></html>
