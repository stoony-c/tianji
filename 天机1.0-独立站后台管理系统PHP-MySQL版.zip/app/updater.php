<?php
function tj_version(): array {return json_decode(file_get_contents(CMS_ROOT.'/app/version.json'),true,16,JSON_THROW_ON_ERROR);}
function tj_requirements(): void {
    foreach(['curl','openssl','zip'] as $ext)if(!extension_loaded($ext))throw new RuntimeException('请在主机 PHP 设置中启用 '.$ext.' 扩展。');
}
function tj_http(string $url,int $limit): string {
    tj_requirements();
    for($i=0;$i<5;$i++){
        $p=parse_url($url);if(($p['scheme']??'')!=='https'||isset($p['user'])||isset($p['pass'])||isset($p['port'])||!in_array($p['host']??'',['api.github.com','github.com','release-assets.githubusercontent.com','objects.githubusercontent.com'],true))throw new RuntimeException('下载地址不属于允许的 GitHub 地址。');
        $body='';$location='';$ch=curl_init($url);
        curl_setopt_array($ch,[CURLOPT_USERAGENT=>'Tianji-Updater/1.1',CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>45,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_HTTPHEADER=>['Accept: application/vnd.github+json'],CURLOPT_WRITEFUNCTION=>static function($ch,$chunk)use(&$body,$limit){if(strlen($body)+strlen($chunk)>$limit)return 0;$body.=$chunk;return strlen($chunk);},CURLOPT_HEADERFUNCTION=>static function($ch,$line)use(&$location){if(stripos($line,'Location:')===0)$location=trim(substr($line,9));return strlen($line);}]);
        $ok=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);
        if($ok===false)throw new RuntimeException('GitHub 下载失败或文件超过限制，请稍后重试。');
        if(in_array($code,[301,302,303,307,308],true)&&$location!==''){$url=$location;continue;}
        if($code!==200)throw new RuntimeException('GitHub 返回 '.$code.'：请确认公开仓库中已有正式 Release 及更新附件。');return $body;
    }throw new RuntimeException('下载重定向次数过多。');
}
function tj_verify(string $raw,string $signature): array {
    $sig=base64_decode(trim($signature),true);
    if($sig===false||openssl_verify($raw,$sig,file_get_contents(CMS_ROOT.'/app/update-public-key.pem'),OPENSSL_ALGO_SHA256)!==1)throw new RuntimeException('更新签名验证失败，未修改程序。');
    $m=json_decode($raw,true,32,JSON_THROW_ON_ERROR);$v=tj_version();
    if(($m['product']??'')!=='tianji'||($m['schema']??0)!==$v['schema'])throw new RuntimeException('此更新需要不同的数据库结构，请使用专门迁移方案。');
    if(!preg_match('/^\d+\.\d+\.\d+$/D',$m['version']??'')||!version_compare($m['version'],$v['version'],'>'))throw new RuntimeException('更新版本不高于当前版本。');
    if(!preg_match('/^[a-f0-9]{64}$/D',$m['sha256']??'')||!is_array($m['files']??null)||count($m['files'])>500||count($m['files'])<1)throw new RuntimeException('更新清单无效。');
    foreach($m['files'] as $path=>$hash)if(!is_string($path)||!tj_allowed_path($path)||!is_string($hash)||!preg_match('/^[a-f0-9]{64}$/D',$hash))throw new RuntimeException('更新包含不允许的文件。');
    if(!isset($m['files']['app/version.json']))throw new RuntimeException('更新缺少版本文件。');
    return $m;
}
function tj_check(bool $force=false): array {
    $path=CMS_ROOT.'/storage/update-check.json';$cached=is_file($path)?json_decode(file_get_contents($path),true):null;
    if(!$force&&is_array($cached)&&($cached['checked']??0)>time()-21600)return $cached;
    $result=['checked'=>time(),'version'=>tj_version()['version'],'latest'=>null,'error'=>''];
    try{
        $release=json_decode(tj_http('https://api.github.com/repos/stoony-c/tianji/releases/latest',1048576),true,32,JSON_THROW_ON_ERROR);
        $tag=$release['tag_name']??'';if(!preg_match('/^v?(\d+\.\d+\.\d+)$/D',$tag,$match)||!empty($release['draft'])||!empty($release['prerelease']))throw new RuntimeException('未找到有效的正式版本。');
        $result['latest']=$match[1];
        if(version_compare($match[1],tj_version()['version'],'>')){
            $assets=[];foreach($release['assets']??[] as $asset)$assets[$asset['name']]=$asset['browser_download_url'];
            $prefix='https://github.com/stoony-c/tianji/releases/download/'.$tag.'/';
            foreach(['tianji-update.json','tianji-update.sig','tianji-update.zip'] as $name)if(($assets[$name]??'')!==$prefix.$name)throw new RuntimeException('Release 缺少已签名的更新附件，请等待发布完成。');
            $raw=tj_http($assets['tianji-update.json'],262144);$sig=tj_http($assets['tianji-update.sig'],16384);$m=tj_verify($raw,$sig);
            if($m['version']!==$match[1])throw new RuntimeException('版本标签与更新清单不一致。');
            $result+=['raw'=>$raw,'signature'=>$sig,'url'=>$assets['tianji-update.zip'],'notes'=>substr((string)($release['body']??''),0,12000)];
        }
    }catch(Throwable $e){$result['error']=$e->getMessage();}
    tj_write($path,json_encode($result,JSON_UNESCAPED_UNICODE));return $result;
}
function tj_unpack(string $zipFile,array $m,string $stage): void {
    $zip=new ZipArchive();if($zip->open($zipFile)!==true)throw new RuntimeException('无法打开更新包。');
    try{
        if($zip->numFiles!==count($m['files']))throw new RuntimeException('压缩包文件数量不符合签名清单。');$seen=[];$size=0;
        for($i=0;$i<$zip->numFiles;$i++){
            $s=$zip->statIndex($i);$path=$s['name'];$zip->getExternalAttributesIndex($i,$opsys,$attr);
            if(!tj_allowed_path($path)||isset($seen[strtolower($path)])||!isset($m['files'][$path])||(($attr>>16)&0170000)===0120000)throw new RuntimeException('压缩包含重复路径、符号链接或非法文件。');
            $seen[strtolower($path)]=true;$size+=$s['size'];if($size>64*1024*1024||$s['size']>8*1024*1024)throw new RuntimeException('解压大小超出限制。');
            $bytes=$zip->getFromIndex($i);if($bytes===false||!hash_equals($m['files'][$path],hash('sha256',$bytes)))throw new RuntimeException('更新文件校验失败。');
            $dest=$stage.'/'.$path;if(!is_dir(dirname($dest))&&!mkdir(dirname($dest),0700,true))throw new RuntimeException('无法创建暂存目录。');if(file_put_contents($dest,$bytes)!==strlen($bytes))throw new RuntimeException('暂存更新失败。');
        }
        $v=json_decode(file_get_contents($stage.'/app/version.json'),true);if(($v['version']??'')!==$m['version']||($v['schema']??0)!==$m['schema'])throw new RuntimeException('版本文件内容不匹配。');
    }finally{$zip->close();}
}
function tj_apply(string $raw,string $signature,string $zipFile): string {
    global $tjLock;
    tj_requirements();$m=tj_verify($raw,$signature);if(!hash_equals($m['sha256'],hash_file('sha256',$zipFile)))throw new RuntimeException('更新包 SHA256 不匹配。');
    $id=bin2hex(random_bytes(12));$dir=CMS_ROOT.'/storage/updates/'.$id;if(!mkdir($dir,0700,true))throw new RuntimeException('无法创建升级目录。');
    tj_unpack($zipFile,$m,$dir.'/stage');
    flock($tjLock,LOCK_UN);if(!flock($tjLock,LOCK_EX))throw new RuntimeException('无法锁定更新，请稍后重试。');
    try{
        tj_recover();tj_verify($raw,$signature);$old=[];
        foreach($m['files'] as $path=>$hash){
            $target=tj_safe_target($path);if(!is_dir(dirname($target))&&!mkdir(dirname($target),0755,true))throw new RuntimeException('无法创建目标目录。');
            if(!is_writable(dirname($target)))throw new RuntimeException('程序目录不可写：'.$path);
            $old[$path]=is_file($target)?hash_file('sha256',$target):null;
            if($old[$path]!==null){$dest=$dir.'/files/'.$path;if(!is_dir(dirname($dest)))mkdir(dirname($dest),0700,true);if(!copy($target,$dest)||hash_file('sha256',$dest)!==$old[$path])throw new RuntimeException('程序备份失败。');}
        }
        $journal=['backup'=>$id,'files'=>$old,'from'=>tj_version()['version'],'to'=>$m['version']];
        tj_write($dir.'/backup.json',json_encode($journal));tj_write(CMS_ROOT.'/storage/update-journal.json',json_encode($journal));
        foreach($m['files'] as $path=>$hash)tj_write(tj_safe_target($path),file_get_contents($dir.'/stage/'.$path));
        foreach($m['files'] as $path=>$hash)if(!hash_equals($hash,hash_file('sha256',tj_safe_target($path))))throw new RuntimeException('升级后文件校验失败。');
        if(!unlink(CMS_ROOT.'/storage/update-journal.json'))throw new RuntimeException('无法完成升级提交。');
        if(is_file(CMS_ROOT.'/storage/update-check.json'))unlink(CMS_ROOT.'/storage/update-check.json');
        tj_write(CMS_ROOT.'/storage/update-status.json',json_encode(['time'=>date('c'),'message'=>'已升级至 '.$m['version'].'，程序备份编号：'.$id],JSON_UNESCAPED_UNICODE));
        return $m['version'];
    }catch(Throwable $e){tj_recover();throw $e;}
    finally{flock($tjLock,LOCK_SH);}
}
