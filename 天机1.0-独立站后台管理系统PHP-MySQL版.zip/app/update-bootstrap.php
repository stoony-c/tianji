<?php
// Stable update protocol: excluded from online replacement.
function tj_allowed_path(string $path): bool {
    if(str_contains($path,'..')||str_contains($path,'\\'))return false;
    if(in_array($path,['app/update-bootstrap.php','app/update-public-key.pem'],true))return false;
    return (bool)preg_match('~^(app/[a-zA-Z0-9_-]+\.php|app/version\.json|assets/[a-zA-Z0-9_/-]+\.(css|js|png|jpg|webp|svg))$~D',$path);
}
function tj_safe_target(string $path): string {
    if(!tj_allowed_path($path))throw new RuntimeException('更新文件路径不被允许。');
    $target=CMS_ROOT.'/'.$path;$cursor=$target;
    while($cursor!==CMS_ROOT){if(is_link($cursor))throw new RuntimeException('更新路径包含符号链接。');$next=dirname($cursor);if($next===$cursor)throw new RuntimeException('无效更新路径。');$cursor=$next;}
    return $target;
}
function tj_write(string $path,string $bytes): void {
    $tmp=tempnam(dirname($path),'.tj-');if(!$tmp)throw new RuntimeException('无法创建临时文件。');
    try{if(file_put_contents($tmp,$bytes)!==strlen($bytes)||!rename($tmp,$path))throw new RuntimeException('写入更新文件失败。');if(function_exists('opcache_invalidate'))opcache_invalidate($path,true);}
    finally{if(is_file($tmp))unlink($tmp);}
}
function tj_recover(): void {
    $journal=CMS_ROOT.'/storage/update-journal.json';if(!is_file($journal))return;
    $j=json_decode(file_get_contents($journal),true,64,JSON_THROW_ON_ERROR);
    if(!preg_match('/^[a-f0-9]{24}$/D',$j['backup']??''))throw new RuntimeException('恢复记录无效。');
    $dir=CMS_ROOT.'/storage/updates/'.$j['backup'];
    foreach($j['files'] as $path=>$hash){
        $target=tj_safe_target($path);
        if($hash===null){if(is_file($target)&&!unlink($target))throw new RuntimeException('无法清理新增文件。');continue;}
        $old=$dir.'/files/'.$path;
        if(!is_file($old)||!hash_equals($hash,hash_file('sha256',$old)))throw new RuntimeException('恢复备份校验失败。');
        tj_write($target,file_get_contents($old));
    }
    if(!unlink($journal))throw new RuntimeException('无法完成恢复。');
    file_put_contents(CMS_ROOT.'/storage/update-status.json',json_encode(['time'=>date('c'),'message'=>'上次升级未完成，已恢复原程序文件。'],JSON_UNESCAPED_UNICODE));
}
$tjLock=fopen(CMS_ROOT.'/storage/runtime.lock','c');
if(!$tjLock||!flock($tjLock,LOCK_SH)){http_response_code(503);exit('系统暂时无法取得文件锁。');}
if(is_file(CMS_ROOT.'/storage/update-journal.json')){
    flock($tjLock,LOCK_UN);flock($tjLock,LOCK_EX);
    try{tj_recover();}catch(Throwable $e){error_log('CMS recovery: '.$e->getMessage());http_response_code(503);exit('升级恢复未完成，请联系管理员检查 storage/updates 内的备份。');}
    flock($tjLock,LOCK_SH);
}
